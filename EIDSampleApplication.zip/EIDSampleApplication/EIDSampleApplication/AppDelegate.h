//
//  AppDelegate.h
//  EIDSampleApplication
//
//  Created by Abrar Ahamed on 28/04/22.
//

#import <UIKit/UIKit.h>
#import "Model.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) Model *model;
@end

