//
//  AppDelegate.m
//  EIDSampleApplication
//
//  Created by Abrar Ahamed on 28/04/22.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self copyFilesToDocumentDirectory:@"config_li" subFileName:@"config_li"];
    [self copyFilesToDocumentDirectory:@"config_lv_qa" subFileName:@"config_lv_qa"];
    [self copyFilesToDocumentDirectory:@"config_pg" subFileName:@"config_pg"];
    [self copyFilesToDocumentDirectory:@"config_tk_qa" subFileName:@"config_tk_qa"];
    [self copyFilesToDocumentDirectory:@"config_vg_qa" subFileName:@"config_vg_qa"];
//    [self copyFilesToDocumentDirectory:@"config_ap" subFileName:@"config_ap"];
    self.model = [[Model alloc]init];
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}

-(void)copyFilesToDocumentDirectory:(NSString *)fileName subFileName:(NSString *)subFileName {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSString *strPath = [self getDocumentDirectoryPath:subFileName];
    
    BOOL success = [fileManager fileExistsAtPath:strPath];
    
    if(!success) {
        NSString *defaultPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:fileName];
        NSLog(@"bundle Path %@",defaultPath);
        success = [fileManager copyItemAtPath:defaultPath toPath:strPath error:&error];
        
        if (!success)
            NSLog(@"%@ not created '%@'.",fileName, [error localizedDescription]);
        else
            NSLog(@"%@ created",fileName);
    }
}
-(NSString *)getDocumentDirectoryPath:(NSString *)stringPath {
    NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString *documentsDir = [arrPaths objectAtIndex:0];
    NSString *strValue = [NSString stringWithFormat:@"%@",[documentsDir stringByAppendingPathComponent:stringPath]];
    return strValue;
}

@end
