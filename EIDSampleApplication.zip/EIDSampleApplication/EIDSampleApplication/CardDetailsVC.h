//
//  CardDetailsVC.h
//  EIDSampleApplication
//
//  Created by Prabhakar Bunga on 28/04/22.
//

#import <UIKit/UIKit.h>
#import <CoreNFC/CoreNFC.h>
#import <IDCardToolkit/IDCardToolkit.h>
#import "Model.h"
#import "AppDelegate.h"
#import "NFCPublicDataVC.h"
NS_ASSUME_NONNULL_BEGIN

@interface CardDetailsVC : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *cardNumTF;
@property (weak, nonatomic) IBOutlet UITextField *dobTF;
@property (weak, nonatomic) IBOutlet UITextField *expireDateTF;
@property (nonatomic, strong) Model *model;
@end

NS_ASSUME_NONNULL_END
