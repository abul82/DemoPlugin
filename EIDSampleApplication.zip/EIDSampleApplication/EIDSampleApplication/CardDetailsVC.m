//
//  CardDetailsVC.m
//  EIDSampleApplication
//
//  Created by Prabhakar Bunga on 28/04/22.
//

#import "CardDetailsVC.h"

@interface CardDetailsVC ()<NFCTagReaderSessionDelegate, UITextFieldDelegate> {
    CardPublicData *cardPublicData;
    NSString *num;
    NSString *dob;
    NSString *expDate;
}
@property(nonatomic)NFCTagReaderSession *session;

@end

@implementation CardDetailsVC
@synthesize cardNumTF, dobTF, expireDateTF;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    AppDelegate *aDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    self.model = aDelegate.model;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)backBtnAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (IBAction)nfcBtnAction:(id)sender {
    if(![self validate]) {
        return;
    }
    num = self.cardNumTF.text;
    dob = self.dobTF.text;
    expDate = self.expireDateTF.text;
    if (@available(iOS 13.0, *)) {
        
          self.session = [[NFCTagReaderSession alloc]
                          initWithPollingOption:NFCPollingISO14443 delegate:self queue:nil];
           self.session.alertMessage =  @"Hold your iPhone near an NFC.";
              [ self.session beginSession];
        
      } else {
           [self showAlertTitle:@"ALERT" withMessage:@"NFC_NOT_SUPPORT" onView:self];
      }
}

-(BOOL)validate {
    if(cardNumTF.text.length == 0) {
        return false;
    } else if(dobTF.text.length == 0) {
        return false;
    } else if(expireDateTF.text.length == 0) {
        return false;
    }
    return true;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField endEditing:true];
    return YES;
}

#pragma mark NFC Tag Readger Methods

- (void)tagReaderSessionDidBecomeActive:(NFCTagReaderSession *)session  API_AVAILABLE(ios(13.0)){
    NSLog(@"tagReaderSessionDidBecomeActive");
    Toolkit *toolkit = self.model.toolkitShared;
               
    if (toolkit==nil) {
        [session invalidateSession];
    }
}

- (void)tagReaderSession:(NFCTagReaderSession *)session didInvalidateWithError:(NSError *)error  API_AVAILABLE(ios(13.0)){
    NSLog(@"readerSession:didInvalidateWithError: (%@)", [error localizedDescription]);
    [self showAlertTitle:@"ALERT" withMessage:[error localizedDescription] onView:self];

}

- (void)tagReaderSession:(NFCTagReaderSession *)session didDetectTags:(NSArray<__kindof id<NFCTag>> *)tags   API_AVAILABLE(ios(13.0)){
     NSLog(@"readerSession:didDetectTags");
    if ([tags count] > 1) {
        [session setAlertMessage:@"More than 1 tag is detected, please try again"];
        [session restartPolling];
        return;
    }
    
     id<NFCTag> firstTag =  tags[0];
     NSLog(@"firstTag %@",firstTag);
    
    if (firstTag.type == NFCTagTypeMiFare) {
        [session setAlertMessage:@"A tag that is not iso7816 is detected, please try again with tag iso7816"];
        NSLog(@"session restartPolling");
         [session restartPolling];
    }
    
    NSString *requestId=[self generateSecureKey];

    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^(void){
    
    if (@available(iOS 13.0, *)) {
        if (firstTag.type == NFCTagTypeISO7816Compatible) {
            id<NFCISO7816Tag> iso7816Tag = [firstTag asNFCISO7816Tag];
            @try {
        
             Toolkit *toolkit = self.model.toolkitShared;
            
            if (toolkit==nil) {
                [session invalidateSession];
            }
        
            [toolkit setNfcTag:session tag:iso7816Tag];
            
            CardReader *cardreader = [toolkit getReaderWithEmiratesId];

            if (cardreader==nil) {
                [session invalidateSession];
            }
            if (!cardreader.isConnected) {
                 [cardreader connect];
            }

                [cardreader setNfcAuthenticationParameters:self->num dateOfBirth:self->dob expiryDate:self->expDate];//parameters are not required for V3 card
    
            dispatch_async(dispatch_get_main_queue(), ^{
                [session setAlertMessage:@"Reading Public Details from card"];
            });// main queue
                  
            self->cardPublicData = [cardreader readPublicData:requestId readnonModifiableData:TRUE readModifiableData:TRUE readPhotography:TRUE readSignatueImage:TRUE readAddress:TRUE];

                dispatch_async(dispatch_get_main_queue(), ^{
        
                    if ([self->cardPublicData getIdNumber]  != nil) {
                        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        NFCPublicDataVC *vc = [sb instantiateViewControllerWithIdentifier:@"NFCPublicDataVC"];
                        vc.cardPublicData = self->cardPublicData;
                        UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:vc];
                        nvc.modalPresentationStyle = UIModalPresentationFullScreen;
                        [self presentViewController:nvc animated:YES completion:nil];
                    }
                     [session setAlertMessage:@"Reading Completed, session going to close"];
                    [session invalidateSession];
                   });// update UI main queue
              }
            @catch (NSException *exception) {
                 [session invalidateSession];
                  NSString *exe =[NSString stringWithFormat:@"%@\n%@\n%@",exception.name,exception.description,exception.userInfo];
                [self showAlertTitle:@"ALERT" withMessage:exe onView:self];
              }// catch
              @finally {
              }// finally
        }
     } else {
         dispatch_async(dispatch_get_main_queue(), ^{
            // Fallback on earlier versions
            [self showAlertTitle:@"ALERT" withMessage:@"NFC_NOT_SUPPORT" onView:self];
         });// update UI main queue
      }
   });// background queue
}
-(NSString*)generateSecureKey {
    NSMutableData *data = [NSMutableData dataWithLength:40];
    int result = SecRandomCopyBytes(kSecRandomDefault, 40, data.mutableBytes);
    if (result != noErr) {
        return @"";
    }
    return [data base64EncodedStringWithOptions:kNilOptions];
}
- (void)showAlertTitle:(NSString *)title withMessage:(NSString *)message onView:(UIViewController *)viewController
{
    dispatch_async(dispatch_get_main_queue(), ^{
   
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:title
                                  message:message
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* okButton = [UIAlertAction
                               actionWithTitle:@"OK"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action)
                               {
                                   [alert dismissViewControllerAnimated:YES completion:nil];
                                   
                               }];
    
    [alert addAction:okButton];
    
    [viewController presentViewController:alert animated:YES completion:nil];
    
   });// update UI main queue
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.cardNumTF endEditing:true];
    [self.dobTF endEditing:true];
    [self.expireDateTF endEditing:true];
}
@end
