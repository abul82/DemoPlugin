//
//  FingerIndex.h
//  IDCardToolkit
//
//  Created by Federal Authority For Identity and Citizenship on 27/09/18.
//  Copyright © 2018 Federal Authority For Identity and Citizenship. All rights reserved.
//

#ifndef FingerIndex_h
#define FingerIndex_h

 enum FingerIndex
{
    None = 0,
    NoMeaning = 3,
    RightThumb = 5,
    RightIndex = 9,
    RightMiddle = 13,
    RightRing = 17,
    RightLittle = 21,
    LeftThumb = 6,
    LeftIndex = 10,
    LeftMiddle = 14,
    LeftRing = 18,
    LeftLittle = 22
};
#endif /* FingerIndex_h */
