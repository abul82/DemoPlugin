//
//  ResponseStatus.h
//  
//
//  Created by Federal Authority For Identity and Citizenship on 17/11/17.
//  Copyright © 2017 Federal Authority For Identity and Citizenship. All rights reserved.
//

//#ifndef ResponseStatus_h
//#define ResponseStatus_h
//
//
//#endif /* ResponseStatus_h */

#import <Foundation/Foundation.h>
typedef enum _ResponseStatus {
    SUCCESS=0,
    CLIENTERROR,
    SERVERERROR
} ResponseStatus;

