//
//  iOSNfcPlugin.h
//  iOSNfcPlugin
//
//  Created by doti naresh on 14/10/19.
//  Copyright © 2019 Federal Authority For Identity and Citizenship. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for iOSNfcPlugin.
FOUNDATION_EXPORT double iOSNfcPluginVersionNumber;

//! Project version string for iOSNfcPlugin.
FOUNDATION_EXPORT const unsigned char iOSNfcPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSNfcPlugin/PublicHeader.h>


#import <iOSNfcPlugin/NFC_Class.h>
