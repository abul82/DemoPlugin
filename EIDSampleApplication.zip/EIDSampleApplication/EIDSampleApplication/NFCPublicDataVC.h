//
//  NFCPublicDataVC.h
//  EIDSampleApplication
//
//  Created by Prabhakar Bunga on 28/04/22.
//

#import <UIKit/UIKit.h>
#import <IDCardToolkit/IDCardToolkit.h>
#import "PublicDataParse.h"
#import "CustomCell.h"
NS_ASSUME_NONNULL_BEGIN

@interface NFCPublicDataVC : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (nonatomic, strong) NSMutableDictionary *pModDataDictionary;
@property (nonatomic, strong) CardPublicData *cardPublicData;
@property (weak, nonatomic) IBOutlet UITableView *listView;
@end

NS_ASSUME_NONNULL_END
