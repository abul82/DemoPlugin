//
//  NFCPublicDataVC.m
//  EIDSampleApplication
//
//  Created by Prabhakar Bunga on 28/04/22.
//

#import "NFCPublicDataVC.h"

@interface NFCPublicDataVC () <UITableViewDelegate,UITableViewDataSource>{
    NSMutableDictionary *dictData;
}

@end

@implementation NFCPublicDataVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    PublicDataParse *parseData=[[PublicDataParse alloc]init];
    dictData=[parseData getNonModifiablePublicDataDetails:[_cardPublicData getNonModifiablePublicData]];
    _listView.delegate = self;
    NSData *photoData = [NSData dataWithBytes:[_cardPublicData getCardHolderPhoto] length:[_cardPublicData getCardHolderPhotoLength]];
    UIImage *pPhotoImage=[[UIImage alloc] initWithData:photoData];
    self.imgView.image=pPhotoImage;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger i = dictData.allKeys.count;
    return i;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CustomCell *cell=(CustomCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    [cell.key setText:dictData.allKeys[indexPath.row]];
    [cell.value setText:dictData.allValues[indexPath.row]];
    return cell;
}
- (IBAction)backBtnAction:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
@end
