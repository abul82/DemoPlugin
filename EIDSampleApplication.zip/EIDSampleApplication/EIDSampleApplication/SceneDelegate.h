//
//  SceneDelegate.h
//  EIDSampleApplication
//
//  Created by Abrar Ahamed on 28/04/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

