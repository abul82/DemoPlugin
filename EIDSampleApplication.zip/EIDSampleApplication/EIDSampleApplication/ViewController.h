//
//  ViewController.h
//  EIDSampleApplication
//
//  Created by Abrar Ahamed on 28/04/22.
//

#import <UIKit/UIKit.h>
#import "Model.h"
#import "PublicDataParse.h"
#import <Foundation/Foundation.h>
#import "CardDetailsVC.h"
#import <IDCardToolkit/IDCardToolkit.h>
#import "AppDelegate.h"

@interface ViewController : UIViewController{
    
    NSMutableDictionary *getpModDataDictionary;
    NSMutableDictionary *getpNonModDataDictionary;
    NSMutableDictionary *getpHomeAddressDictionary;
    NSMutableDictionary *getpWorkAddressDictionary;
    
    NSMutableArray *pIDNumberKeyarr;
    NSMutableArray *pIDNumberValuearr;
    NSMutableArray *pModDatakeyarr;
    NSMutableArray *pModDataValuearr;
    NSMutableArray *pNonModDatakeyarr;
    NSMutableArray *pNonModDataValuearr;
    NSMutableArray *pHomeAddresskeyarr;
    NSMutableArray *pHomeAddressValuearr;
    NSMutableArray *pWorkAddresskeyarr;
    NSMutableArray *pWorkAddressValuearr;
    
}

@property(nonatomic,strong)Toolkit *toolkit;
@property (nonatomic, strong) Model *model;
@property (weak, nonatomic) IBOutlet UILabel *op_lbl;
@property (weak, nonatomic) IBOutlet UIButton *initializationBtn;
@property (weak, nonatomic) IBOutlet UIButton *get_list_readers_btn;
@property (weak, nonatomic) IBOutlet UIButton *nfv_read_data_btn;
@property (weak, nonatomic) IBOutlet UIButton *connect_reader_btn;


@end

