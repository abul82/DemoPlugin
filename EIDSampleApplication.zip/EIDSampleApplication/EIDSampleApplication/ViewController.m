//
//  ViewController.m
//  EIDSampleApplication
//
//  Created by Abrar Ahamed on 28/04/22.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize op_lbl, initializationBtn, connect_reader_btn, nfv_read_data_btn, get_list_readers_btn;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    AppDelegate *aDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    self.model = aDelegate.model;
    
    getpModDataDictionary=[[NSMutableDictionary alloc]init];
    getpNonModDataDictionary=[[NSMutableDictionary alloc]init];
    getpHomeAddressDictionary=[[NSMutableDictionary alloc]init];
    getpWorkAddressDictionary=[[NSMutableDictionary alloc]init];
    
    pIDNumberKeyarr=[[NSMutableArray alloc]init];
    pIDNumberValuearr=[[NSMutableArray alloc]init];
    pModDatakeyarr=[[NSMutableArray alloc]init];
    pModDataValuearr=[[NSMutableArray alloc]init];
    pNonModDatakeyarr=[[NSMutableArray alloc]init];
    pNonModDataValuearr=[[NSMutableArray alloc]init];
    pHomeAddresskeyarr=[[NSMutableArray alloc]init];
    pHomeAddressValuearr=[[NSMutableArray alloc]init];
    pWorkAddresskeyarr=[[NSMutableArray alloc]init];
    pWorkAddressValuearr=[[NSMutableArray alloc]init];
    
}

- (IBAction)initializationBtnAction:(id)sender {
    if(self.toolkit){
        [op_lbl setText:@"Initialized Already!"];
    } else {
        [self initializationToolKit];
    }
}

- (IBAction)getReadersListBtnAction:(id)sender {
    if(self.toolkit) {
        [self getReadersList];
    } else {
        [op_lbl setText:@"Please Initialize"];
    }
}

- (IBAction)nfcReadDataBtnAction:(id)sender {
    if(self.toolkit) {
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        CardDetailsVC *vc = [sb instantiateViewControllerWithIdentifier:@"CardDetailsVC"];
        UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:vc];
        nvc.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:nvc animated:YES completion:nil];
    } else {
        [op_lbl setText:@"Please Initialize"];
    }
}

- (IBAction)connectReaderBtnAction:(id)sender {
    if(self.toolkit) {
        [self connectToReader];
    } else {
        [op_lbl setText:@"Please Initialize"];
    }
}
- (IBAction)cleanUpBtnAction:(id)sender {
    if(self.toolkit) {
        [self.toolkit cleanup];
        self.toolkit = nil;
        [op_lbl setText:@"Cleaned"];
    } else {
        [op_lbl setText:@"Please Initialize"];
    }
}


-(void)initializationToolKit {
    NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString *documentsDir = [arrPaths objectAtIndex:0];
    NSString *fileName = [NSString stringWithFormat:@"%@",[documentsDir stringByAppendingPathComponent:@""]];
    NSString *default_log_paramsPath = [NSString stringWithFormat:@"%@/",fileName];
    NSString *default_config_paramsPath = [NSString stringWithFormat:@"%@",fileName];
    
    //    default_log_paramsPath
    NSString *dummyUrl =@""; //Dummy url and keep internet disconnect for offline
    self.model.mLogDir=default_log_paramsPath;
    self.model.mVGurl= dummyUrl;
    self.model.mConfigUrl=default_config_paramsPath;
    
    
    const char *vg_Url= self.model.mVGurl.UTF8String;
    const char *config_dir= self.model.mConfigUrl.UTF8String;
    const char *log_Dir= self.model.mLogDir.UTF8String;
    
    char config_params[3000]={0};
    if(!vg_Url[0]) {
        snprintf(config_params, sizeof(config_params), "config_directory = %s\n log_directory = %s\n", config_dir, log_Dir);
    }
    else{
        snprintf(config_params, sizeof(config_params), "config_directory = %s\nlog_directory = %s\nvg_url = %s",
                 config_dir, log_Dir, vg_Url);
    }
    
    NSString *configParams=[NSString stringWithFormat:@"%s",config_params];
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        @try {
            
            self.toolkit =[[Toolkit alloc]initWithToolkit:YES configParams:configParams];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.model.toolkitShared=self->_toolkit;
                [self.op_lbl setText:@"INITIALIZED"];
            });
            
        }//try
        @catch (NSException *exception) {
            NSString *exe =[NSString stringWithFormat:@"%@\n%@\n%@",exception.name,exception.description,exception.userInfo];
            [self showAlertTitle:@"ALERT" withMessage:exe onView:self];
        }// catch
        
    });
}

-(void)getReadersList {
    NSArray *cardReaderSharedArray =[self.toolkit listReaders];
    [op_lbl setText:@""];
    NSString *str;
    for (CardReader *card in cardReaderSharedArray) {
        if(str == NULL) {
            str = [NSString stringWithFormat:@"%@",card.getName];
        } else {
            str = [NSString stringWithFormat:@"%@, %@",str,card.getName];
        }
    }
    [op_lbl setText:[NSString stringWithFormat:@"%@",str]];
}

-(void)connectToReader {
    NSArray *cardReaderSharedArray =[self.toolkit listReaders];
    if(cardReaderSharedArray.count > 0) {
        NSInteger i = 0;
        for (CardReader *card in cardReaderSharedArray) {
            i++;
            if(![card.getName containsString:@"NFC"]) {
            CardReader *cardreader  = [cardReaderSharedArray objectAtIndex:i];
            [cardreader connect];//Connect to the Reader
            NSString *requestId = [self generateSecureKey];
            
            CardPublicData *cardPublicData = [cardreader readPublicData:requestId readnonModifiableData:TRUE readModifiableData:TRUE readPhotography:FALSE readSignatueImage:FALSE readAddress:TRUE];
                
                UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                NFCPublicDataVC *vc = [sb instantiateViewControllerWithIdentifier:@"NFCPublicDataVC"];
                vc.cardPublicData = cardPublicData;
                UINavigationController *nvc = [[UINavigationController alloc] initWithRootViewController:vc];
                nvc.modalPresentationStyle = UIModalPresentationFullScreen;
                [self presentViewController:nvc animated:YES completion:nil];
            
//            [self->pIDNumberKeyarr addObject:@"IDNumber"];
//            [self->pIDNumberKeyarr addObject:@"CardNumber"];
//            [self->pIDNumberValuearr addObject:[cardPublicData getIdNumber]];
//            [self->pIDNumberValuearr addObject:[cardPublicData getCardNumber]];
//
//            PublicDataParse *parseData=[[PublicDataParse alloc]init];
//            self->getpModDataDictionary=[parseData getModifiablePublicDataDetails:[cardPublicData getModifiablePublicData]];
//            self->getpNonModDataDictionary=[parseData getNonModifiablePublicDataDetails:[cardPublicData getNonModifiablePublicData]];
//            self->getpHomeAddressDictionary=[parseData getHomeAddressDetails:[cardPublicData getHomeAddress]];
//            self->getpWorkAddressDictionary=[parseData getWorkAddressDetails:[cardPublicData getWorkAddress]];
                [op_lbl setText:[NSString stringWithFormat:@"%@",card.getName]];
                break;
            } else {
                if(cardReaderSharedArray.count == 1) {
                    [op_lbl setText:[NSString stringWithFormat:@"%@ only Available",card.getName]];
                    
                }
            }
        }
    }
}


- (void)showAlertTitle:(NSString *)title withMessage:(NSString *)message onView:(UIViewController *)viewController
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:title
                                      message:message
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
            [alert dismissViewControllerAnimated:YES completion:nil];
            
        }];
        
        [alert addAction:okButton];
        
        [viewController presentViewController:alert animated:YES completion:nil];
        
    });// update UI main queue
}

-(NSString*)generateSecureKey {
    NSMutableData *data = [NSMutableData dataWithLength:40];
    int result = SecRandomCopyBytes(kSecRandomDefault, 40, data.mutableBytes);
    if (result != noErr) {
        return @"";
    }
    return [data base64EncodedStringWithOptions:kNilOptions];
}
@end
