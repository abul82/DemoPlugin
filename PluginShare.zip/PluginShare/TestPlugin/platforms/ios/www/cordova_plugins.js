cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-emiratesid.eidCordovaPlugin",
      "file": "plugins/cordova-plugin-emiratesid/www/eidCordovaPlugin.js",
      "pluginId": "cordova-plugin-emiratesid",
      "clobbers": [
        "cordova.plugins.eidCordovaPlugin"
      ]
    },
    {
      "id": "cordova-plugin-emiratesid.config_li",
      "file": "plugins/cordova-plugin-emiratesid/www/config_li",
      "pluginId": "cordova-plugin-emiratesid"
    },
    {
      "id": "cordova-plugin-emiratesid.config_lv_qa",
      "file": "plugins/cordova-plugin-emiratesid/www/config_lv_qa",
      "pluginId": "cordova-plugin-emiratesid"
    },
    {
      "id": "cordova-plugin-emiratesid.config_pg",
      "file": "plugins/cordova-plugin-emiratesid/www/config_pg",
      "pluginId": "cordova-plugin-emiratesid"
    },
    {
      "id": "cordova-plugin-emiratesid.config_tk_qa",
      "file": "plugins/cordova-plugin-emiratesid/www/config_tk_qa",
      "pluginId": "cordova-plugin-emiratesid"
    },
    {
      "id": "cordova-plugin-emiratesid.config_vg_qa",
      "file": "plugins/cordova-plugin-emiratesid/www/config_vg_qa",
      "pluginId": "cordova-plugin-emiratesid"
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-emiratesid": "2.0.1"
  };
});