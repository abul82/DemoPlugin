cordova.define("cordova-plugin-emiratesid.eidCordovaPlugin", function(require, exports, module) {
var exec = require('cordova/exec');

var eidCordovaPlugin = {

InitializeFramework: function (success, error) {
     exec(success, error, 'eidCordovaPlugin', 'InitializeFramework', []);
},

ReadPublicData: function (success, error) {
exec(success, error, 'eidCordovaPlugin', 'ReadPublicData', []);
},

ReadPublicDataFlexible: function (success, error,
withFacialImage=true,
withSignatureImage=true,
withAddressData= true) 
{

    exec(
        success,
        error,
        'eidCordovaPlugin',
        ReadPublicDataFlexible,
        [withFacialImage, withSignatureImage, withAddressData]
        );
    }
};
module.exports = eidCordovaPlugin;
});
