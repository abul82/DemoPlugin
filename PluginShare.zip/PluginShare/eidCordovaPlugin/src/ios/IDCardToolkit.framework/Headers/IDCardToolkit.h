//
//  IDCardToolkit.h
//  IDCardToolkit
//
//  Created by Federal Authority For Identity and Citizenship on 20/12/17.
//  Copyright © 2017 Federal Authority For Identity and Citizenship. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IDCardToolkit.
FOUNDATION_EXPORT double IDCardToolkitVersionNumber;

//! Project version string for IDCardToolkit.
FOUNDATION_EXPORT const unsigned char IDCardToolkitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IDCardToolkit/PublicHeader.h>

#import <IDCardToolkit/EIDAToolkitTypes.h>
#import <IDCardToolkit/EIDAToolkitInternal.h>
#import <IDCardToolkit/Toolkit.h>
#import <IDCardToolkit/CardReader.h>
#import <IDCardToolkit/CardCertificates.h>
#import <IDCardToolkit/CardFamilyBookData.h>
#import <IDCardToolkit/CardPublicData.h>
#import <IDCardToolkit/Child.h>
#import <IDCardToolkit/FingerData.h>
#import <IDCardToolkit/HeadOfFamily.h>
#import <IDCardToolkit/ModifiablePublicData.h>
#import <IDCardToolkit/NonModifiablePublicData.h>
#import <IDCardToolkit/RegisterDeviceResponse.h>
#import <IDCardToolkit/ResponseStatus.h>
#import <IDCardToolkit/SHXMLParser.h>
#import <IDCardToolkit/SignatureResponse.h>
#import <IDCardToolkit/ToolkitResponse.h>
#import <IDCardToolkit/ToolkitXmlDataObject.h>
#import <IDCardToolkit/ToolkitException.h>
#import <IDCardToolkit/Wife.h>
#import <IDCardToolkit/WorkAddress.h>
#import <IDCardToolkit/HomeAddress.h>
#import <IDCardToolkit/SignatureValidator.h>
#import <IDCardToolkit/DataContainer.h>
#import <IDCardToolkit/HealthDataContainer.h>
#import <IDCardToolkit/AllergyResource.h>
#import <IDCardToolkit/BloodGroupResource.h>
#import <IDCardToolkit/DiagnosisResource.h>
#import <IDCardToolkit/InsuranceResource.h>

