//
//  Toolkit.h
//
//  Created by Federal Authority For Identity and Citizenship on 16/11/17.
//  Copyright © 2017 Federal Authority For Identity and Citizenship. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CardReader.h"
#import "RegisterDeviceResponse.h"
#import "DataProtectionKey.h"

@interface Toolkit : NSObject

-(instancetype)initWithToolkit:(BOOL)inProcessMode configParams:(NSString *)configParams;
-(NSString *)getToolkitVersion;
-(NSString *)prepareRequest:(NSString*)requestId;
-(RegisterDeviceResponse *)registerDevice:(NSString *)encodedUserId encodedPassword:(NSString *)encodedPassword deviceReferenceId:(NSString *)deviceReferenceId;
-(DataProtectionKey *)getDataProtectionKey;
-(NSArray * )listReaders;
-(CardReader *)getReaderWithEmiratesId;
-(NSString *)getDeviceId;
-(NSString *)getStatusMessage:(int)status;
-(void)FreeMemory:(void*)buffer;
-(void)cleanup;
-(void)setNfcTag:(id)session tag:(id)tag;
-(void)parseMRZData:(NSString *)mrz;
-(NSString *)getMrzDocument_type;
-(NSString *)getMrzIssued_country;
-(NSString *)getMrzCardnumber;
-(NSString *)getMrzIdnumber;
-(NSString *)getMrzDate_of_birth;
-(NSString *)getMrzGender;
-(NSString *)getMrzCard_expiry_date;
-(NSString *)getMrzNationality;
-(NSString *)getMrzFullname;
-(NSString *)getLicenseExpiryDate;
-(void)getConfigCertificateExpiryDate;
-(NSString *)getConfig_vg_cert_expiry;
-(NSString *)getConfig_lv_cert_expiry;
-(NSString *)getServer_tls_cert_expiry;
-(NSString *)getConfig_ag_cert_expiry;
-(NSString *)getLicense_expiry;
@end
