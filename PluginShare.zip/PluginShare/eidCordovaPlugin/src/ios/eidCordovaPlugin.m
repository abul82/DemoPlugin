/********* eidCordovaPlugin.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>

@interface eidCordovaPlugin : CDVPlugin {
  // Member variables go here.
}

- (void) pluginInitialize;
- (void)coolMethod:(CDVInvokedUrlCommand*)command;
- (void)InitializeFramework:(CDVInvokedUrlCommand*)command;
@end

@implementation eidCordovaPlugin

- (void)pluginInitialize
{
     NSLog(@"pluginInitialze Methode Called");

    [self copyFilesToDocumentDirectory:@"config_li" subFileName:@"config_li"];
    [self copyFilesToDocumentDirectory:@"config_lv_qa" subFileName:@"config_lv_qa"];
    [self copyFilesToDocumentDirectory:@"config_pg" subFileName:@"config_pg"];
    [self copyFilesToDocumentDirectory:@"config_tk_qa" subFileName:@"config_tk_qa"];
    [self copyFilesToDocumentDirectory:@"config_vg_qa" subFileName:@"config_vg_qa"];
    //  CDVPluginResult* pluginResult = nil;
    //  pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    //   [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];

}

- (void)InitializeFramework:(CDVInvokedUrlCommand*)command
{
  CDVPluginResult* pluginResult = nil;
     pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
      [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}
- (void)coolMethod:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult* pluginResult = nil;
    NSString* echo = [command.arguments objectAtIndex:0];

    if (echo != nil && [echo length] > 0) {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:echo];
    } else {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR];
    }

    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}
-(void)copyFilesToDocumentDirectory:(NSString *)fileName subFileName:(NSString *)subFileName {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSString *strPath = [self getDocumentDirectoryPath:subFileName];
    
    BOOL success = [fileManager fileExistsAtPath:strPath];
    
    if(!success) {
        NSString *defaultPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"www/plugins/cordova-plugin-emiratesid/www"];
        NSLog(@"bundle Path %@",defaultPath);
        success = [fileManager copyItemAtPath:defaultPath toPath:strPath error:&error];
        
        if (!success)
            NSLog(@"%@ not created '%@'.",fileName, [error localizedDescription]);
        else
            NSLog(@"%@ created",fileName);
    }
}
-(NSString *)getDocumentDirectoryPath:(NSString *)stringPath {
    NSArray *arrPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
    NSString *documentsDir = [arrPaths objectAtIndex:0];
    NSString *strValue = [NSString stringWithFormat:@"%@",[documentsDir stringByAppendingPathComponent:stringPath]];
    return strValue;
}

@end
