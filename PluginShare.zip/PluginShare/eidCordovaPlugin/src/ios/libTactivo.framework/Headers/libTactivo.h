//
//  libTactivo.h
//  libTactivo
//
//  Created by doti naresh on 26/11/21.
//

#import <Foundation/Foundation.h>

//! Project version number for libTactivo.
FOUNDATION_EXPORT double libTactivoVersionNumber;

//! Project version string for libTactivo.
FOUNDATION_EXPORT const unsigned char libTactivoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libTactivo/PublicHeader.h>

#import <Nefcom/EIDAToolkitPlugin.h>


